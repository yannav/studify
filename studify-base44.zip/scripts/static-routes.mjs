import { copyFile, mkdir } from 'node:fs/promises'
import { join } from 'node:path'

// Directory indexes let static hosts serve direct links without a Worker.
const routes = ['about', 'pricing', 'styleguide', 'login', 'signup', 'app', 'app/chat', 'app/flashcards', 'app/quiz', 'app/planner']

for (const route of routes) {
  const directory = join('dist', route)
  await mkdir(directory, { recursive: true })
  await copyFile('dist/index.html', join(directory, 'index.html'))
}
