# Studify for Base44

This package contains the merged Studify web app with Study Astra planning,
notes, syllabus tracking, exams, progress, and focus sessions.

| Folder | Contents |
| --- | --- |
| `src/` | React and TypeScript app |
| `public/` | Images and favicon |
| `base44/` | Base44 hosting configuration |
| `dist/` | Prebuilt files for Base44 hosting |
| `scripts/` | Build step that creates static indexes for direct page links |

## Deploy to Base44

Use Node.js 20.19 or newer for the Base44 CLI. Extract the archive, open
the project folder in a terminal, and sign in to Base44.

```sh
npx base44@0.3.6 login
npx base44@0.3.6 link
npx base44@0.3.6 site deploy --no-build --publish
npx base44@0.3.6 site open
```

Choose the Base44 app you intend to publish when linking. The last command
opens the resulting site. The archive includes the built site, so a local
build is optional for this first deploy.

## Edit and rebuild

Install Bun and run these commands from the project folder.

```sh
bun install --frozen-lockfile
bun run typecheck
bun run build
bun run preview
```

## How the hosted copy works

The app processes documents and answers tutor questions in the browser.
The library, planner, and progress use browser storage. To move data from
a different Studify origin, export a backup in its Account menu and restore
it on the new site. The planner can also import a Study Astra JSON export.

Base44 provides static hosting for this edition. Sign-in and signup are demo
profiles, and newsletter and contact forms validate input locally without
delivering messages. Base44 authentication, database sync, and email delivery
would require separate integrations.
