import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import { BarChart3, BookOpen, CalendarDays, CheckSquare, FileText, Timer, Trash2 } from 'lucide-react'

import { Button, ButtonLink, IconButton } from '../../components/Button'
import { Notice } from '../../components/Notice'
import { Segmented } from '../../components/Segmented'
import { useT } from '../../lib/i18n'
import { docTitle, markStudied, packOf, useAttempts, useDocs } from '../../lib/library'
import { useLocation } from '../../lib/router'
import { examReadiness, importAstraPlan, mergeStudyPlans, useFocusTimer, useStudyPlan } from '../../lib/studyPlan'
import type { PlanItem, PlanKind } from '../../lib/studyPlan'
import { AppHeader } from './AppHeader'

const sections = [
  { value: 'task', label: 'Tasks', icon: CheckSquare },
  { value: 'topic', label: 'Syllabus', icon: BookOpen },
  { value: 'exam', label: 'Exams', icon: CalendarDays },
  { value: 'note', label: 'Notes', icon: FileText },
  { value: 'focus', label: 'Focus', icon: Timer },
  { value: 'progress', label: 'Progress', icon: BarChart3 },
] as const

export function PlannerPage() {
  const t = useT()
  const [plan, setPlan] = useStudyPlan()
  const [docs] = useDocs()
  const [attempts] = useAttempts()
  const { search } = useLocation()
  const fromDoc = docs.find((doc) => doc.id === new URLSearchParams(search).get('doc'))
  const [section, setSection] = useState<PlanKind | 'focus' | 'progress'>('task')
  const [editing, setEditing] = useState<PlanItem | null>(null)
  const [message, setMessage] = useState<{ error: boolean; text: string } | null>(null)
  const file = useRef<HTMLInputElement>(null)
  const subjects = [...new Set([...docs.map((doc) => packOf(doc).subject), ...plan.items.map((item) => item.subject), ...plan.sessions.map((session) => session.subject)].filter(Boolean))]
  const tasks = plan.items.filter((item) => item.kind === 'task')
  const topics = plan.items.filter((item) => item.kind === 'topic')
  const upcoming = plan.items.filter((item) => item.kind === 'exam' && item.date >= localDate()).sort(byDate)
  const minutes = plan.sessions.reduce((sum, session) => sum + session.minutes, 0)

  function save(event: FormEvent<HTMLFormElement>, kind: PlanKind) {
    event.preventDefault()
    const form = event.currentTarget
    const data = new FormData(form)
    const value = (key: string) => String(data.get(key) ?? '').trim()
    const title = value('title')
    if (!title) return
    const docId = value('docId')
    const doc = docs.find((entry) => entry.id === docId)
    const item: PlanItem = {
      id: editing?.id ?? crypto.randomUUID(), kind, title, date: value('date'), content: value('content'),
      subject: doc ? packOf(doc).subject : value('subject'), docId, done: editing?.done ?? false,
    }
    setPlan((prev) => ({
      ...prev,
      items: editing ? prev.items.map((entry) => entry.id === item.id ? item : entry) : [...prev.items, item],
    }))
    form.reset()
    setEditing(null)
  }

  async function importPlan(chosen: File) {
    try {
      const imported = importAstraPlan(await chosen.text())
      if (!imported || (!imported.items.length && !imported.sessions.length)) throw new Error()
      setPlan((prev) => mergeStudyPlans(prev, imported))
      setMessage({ error: false, text: t('Study Astra plan imported.') })
    } catch {
      setMessage({ error: true, text: t('Choose a Study Astra JSON export with study plan data.') })
    }
  }

  function subjectProgress(subject: string) {
    const matches = (name: string) => !!subject && name.trim().toLowerCase() === subject.trim().toLowerCase()
    const syllabus = topics.filter((item) => {
      const linked = docs.find((doc) => doc.id === item.docId)
      return matches(linked ? packOf(linked).subject : item.subject)
    })
    const coverage = syllabus.length ? 100 * syllabus.filter((item) => item.done).length / syllabus.length : 0
    const docIds = new Set(docs.filter((doc) => matches(packOf(doc).subject)).map((doc) => doc.id))
    const quizzes = attempts.filter((attempt) => docIds.has(attempt.docId) && attempt.total > 0)
    const quiz = quizzes.length ? 100 * quizzes.reduce((sum, attempt) => sum + attempt.score / attempt.total, 0) / quizzes.length : 0
    const studied = plan.sessions.filter((session) => matches(session.subject)).reduce((sum, session) => sum + session.minutes, 0)
    return { coverage, quiz: quizzes.length ? quiz : null, studied }
  }

  const recentAttempts = [...attempts].reverse()
  const review = docs.flatMap((doc) => {
    const last = recentAttempts.find((attempt) => attempt.docId === doc.id && attempt.total > 0)
    return last && last.score / last.total < 0.7 ? [{ doc, score: Math.round(last.score / last.total * 100) }] : []
  }).sort((a, b) => a.score - b.score).slice(0, 3)

  const displayed = plan.items.filter((item) => item.kind === section).sort(byDate)
  const current = sections.find((item) => item.value === section)!
  return (
    <>
      <AppHeader title={t('Study planner')} lede={t('Plan what to study, track your syllabus and prepare for exams.')}>
        <Button variant="glass" onClick={() => file.current?.click()}>{t('Import Study Astra plan')}</Button>
        <input ref={file} type="file" accept=".json,application/json" className="hidden" onChange={(event) => {
          const chosen = event.target.files?.[0]
          event.target.value = ''
          if (chosen) void importPlan(chosen)
        }} />
      </AppHeader>
      <div className="mx-auto grid max-w-6xl gap-6 px-5 py-8 sm:px-8 lg:px-10">
        {message && <Notice tone={message.error ? 'error' : 'success'}>{message.text}</Notice>}
        <dl className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            [t('Open tasks'), tasks.filter((item) => !item.done).length],
            [t('Topics completed'), `${topics.filter((item) => item.done).length}/${topics.length}`],
            [t('Focus minutes'), minutes],
            [t('Upcoming exams'), upcoming.length],
          ].map(([label, value]) => (
            <div key={label} className="panel rounded-[22px] p-4 sm:p-5">
              <dt className="text-sm text-muted">{label}</dt>
              <dd className="mt-2 text-3xl tracking-tight">{value}</dd>
            </div>
          ))}
        </dl>
        {section === 'task' && review.length > 0 && (
          <section className="panel grid gap-3 rounded-[22px] p-5">
            <h2 className="text-lg">{t('Needs review')}</h2>
            {review.map(({ doc, score }) => (
              <div key={doc.id} className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm text-soft">{docTitle(doc)} · {t('Last quiz: {n}%', { n: score })}</p>
                <ButtonLink variant="glass" size="sm" href={`/app/flashcards?doc=${encodeURIComponent(doc.id)}`}>{t('Review cards')}</ButtonLink>
              </div>
            ))}
          </section>
        )}
        <div className="max-w-full overflow-x-auto">
          <Segmented label={t('Study planner')} value={section} onChange={(value) => {
            setSection(value as typeof section)
            setEditing(null)
          }} options={sections.map(({ value, label }) => ({ value, label: t(label) }))} />
        </div>

        {section === 'focus' ? <FocusPanel subjects={subjects} /> : section === 'progress' ? (
          <section className="grid gap-3 sm:grid-cols-2" aria-label={t('Progress')}>
            {subjects.length === 0 && <p className="panel rounded-[22px] p-5 text-sm text-muted">{t('Add a subject to track your progress.')}</p>}
            {subjects.map((subject) => {
              const { coverage, quiz, studied } = subjectProgress(subject)
              return (
                <article key={subject} className="panel grid gap-3 rounded-[22px] p-5">
                  <h2 className="break-words text-lg">{subject}</h2>
                  <dl className="grid grid-cols-3 gap-2 text-sm">
                    <div><dt className="text-muted">{t('Syllabus')}</dt><dd>{Math.round(coverage)}%</dd></div>
                    <div><dt className="text-muted">{t('Quiz average')}</dt><dd>{quiz === null ? t('None yet') : `${Math.round(quiz)}%`}</dd></div>
                    <div><dt className="text-muted">{t('Focus minutes')}</dt><dd>{studied}</dd></div>
                  </dl>
                </article>
              )
            })}
          </section>
        ) : (
          <div className="grid items-start gap-5 xl:grid-cols-[minmax(280px,1fr)_minmax(0,1.6fr)]">
            <form key={editing?.id ?? `${section}:${fromDoc?.id ?? ''}`} className="panel grid gap-3 rounded-[22px] p-5" onSubmit={(event) => save(event, section)}>
              <h2 className="flex items-center gap-2 text-lg">
                <current.icon className="size-4 text-leaf-text" aria-hidden />
                {t(editing ? 'Edit entry' : { task: 'Add task', topic: 'Add topic', exam: 'Add exam', note: 'Add note' }[section])}
              </h2>
              <label className="grid gap-1 text-sm">{t('Title')}<input className="field" name="title" required maxLength={140} defaultValue={editing?.title ?? (fromDoc && section === 'task' ? t('Review {file}', { file: docTitle(fromDoc) }) : '')} /></label>
              <label className="grid gap-1 text-sm">{t('Subject')}<input className="field" name="subject" list="plan-subjects" maxLength={80} defaultValue={editing?.subject} /></label>
              <datalist id="plan-subjects">{subjects.map((subject) => <option key={subject} value={subject} />)}</datalist>
              {(section === 'task' || section === 'exam') && (
                <label className="grid gap-1 text-sm">{t(section === 'exam' ? 'Exam date' : 'Due date')}
                  <input name="date" className="field" type="date" required={section === 'exam'} defaultValue={editing?.date} />
                </label>
              )}
              {docs.length > 0 && (
                <label className="grid gap-1 text-sm">{t('Library file')}
                  <select className="field" name="docId" defaultValue={editing?.docId ?? fromDoc?.id}>
                    <option value="">{t('No file linked')}</option>
                    {docs.map((doc) => <option key={doc.id} value={doc.id}>{docTitle(doc)}</option>)}
                  </select>
                </label>
              )}
              <label className="grid gap-1 text-sm">{t(section === 'note' ? 'Note' : 'Details')}
                <textarea className="field min-h-24 py-3" name="content" required={section === 'note'} defaultValue={editing?.content} />
              </label>
              <div className="flex flex-wrap gap-2">
                <Button variant="leaf" type="submit">{t(editing ? 'Save changes' : 'Add to plan')}</Button>
                {editing && <Button variant="ghost" onClick={() => setEditing(null)}>{t('Cancel')}</Button>}
              </div>
            </form>
            <section aria-label={t(current.label)} className="grid gap-3">
              {displayed.length === 0 && <p className="panel rounded-[22px] p-6 text-sm text-muted">{t('No entries yet.')}</p>}
              {displayed.map((item) => {
                const doc = docs.find((entry) => entry.id === item.docId)
                const subject = doc ? packOf(doc).subject : item.subject
                const progress = item.kind === 'exam' && subject ? subjectProgress(subject) : null
                return (
                  <article key={item.id} className="panel grid min-w-0 gap-3 rounded-[22px] p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className={item.done ? 'break-words text-muted line-through' : 'break-words'}>{item.title}</h3>
                        <p className="break-words text-sm text-muted">{[subject, item.date].filter(Boolean).join(' · ')}</p>
                      </div>
                      <IconButton size="sm" variant="ghost" label={t('Delete {title}', { title: item.title })} onClick={() => {
                        setPlan((prev) => ({ ...prev, items: prev.items.filter((entry) => entry.id !== item.id) }))
                        if (editing?.id === item.id) setEditing(null)
                      }}><Trash2 className="size-4" /></IconButton>
                    </div>
                    {item.content && <p className="whitespace-pre-wrap break-words text-sm text-soft">{item.content}</p>}
                    {progress && <p className="text-sm text-leaf-text">{t('Estimated readiness: {n}%', { n: examReadiness(progress.coverage, progress.quiz ?? 0, progress.studied) })}</p>}
                    <div className="flex flex-wrap items-center gap-2">
                      {(item.kind === 'task' || item.kind === 'topic') && (
                        <label className="mr-2 flex items-center gap-2 text-sm text-soft">
                          <input type="checkbox" className="accent-leaf" checked={item.done} aria-label={item.title} onChange={(event) => {
                            const done = event.target.checked
                            setPlan((prev) => ({ ...prev, items: prev.items.map((entry) => entry.id === item.id ? { ...entry, done } : entry) }))
                            if (editing?.id === item.id) setEditing({ ...editing, done })
                            if (done) markStudied()
                          }} />{t('Complete')}
                        </label>
                      )}
                      <Button variant="ghost" size="sm" onClick={() => setEditing(item)}>{t('Edit')}</Button>
                      {doc && <ButtonLink variant="glass" size="sm" href={`/app/quiz?doc=${encodeURIComponent(doc.id)}`}>{t('Practice quiz')}</ButtonLink>}
                    </div>
                  </article>
                )
              })}
            </section>
          </div>
        )}
      </div>
    </>
  )
}

function localDate(date = new Date()) {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000)
  return local.toISOString().slice(0, 10)
}

function byDate(a: PlanItem, b: PlanItem) {
  return (a.date || '9999').localeCompare(b.date || '9999')
}

function FocusPanel({ subjects }: { subjects: string[] }) {
  const t = useT()
  const [plan] = useStudyPlan()
  const [timer, setTimer] = useFocusTimer()
  const [now, setNow] = useState(Date.now)

  useEffect(() => {
    if (!timer?.ends) return
    const interval = window.setInterval(() => setNow(Date.now()), 250)
    return () => window.clearInterval(interval)
  }, [timer?.ends])

  const seconds = timer ? Math.max(0, Math.ceil((timer.ends ? timer.ends - now : timer.remaining) / 1000)) : 0
  const clock = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`
  return (
    <section className="panel grid gap-4 rounded-[22px] p-5 sm:p-6">
      <h2 className="text-lg">{t('Focus timer')}</h2>
      {timer ? (
        <>
          <p className="text-5xl tabular-nums" role="timer">{clock}</p>
          <p className="text-muted">{timer.subject}</p>
          <div className="flex gap-2">
            <Button variant="leaf" onClick={() => {
              const at = Date.now()
              setNow(at)
              if (timer.ends && timer.ends <= at) return
              setTimer(timer.ends ? { ...timer, ends: 0, remaining: timer.ends - at }
                : { ...timer, ends: at + timer.remaining })
            }}>{t(timer.ends ? 'Pause' : 'Resume')}</Button>
            <Button variant="glass" onClick={() => setTimer(null)}>{t('Cancel session')}</Button>
          </div>
        </>
      ) : (
        <form className="flex flex-wrap items-end gap-3" onSubmit={(event) => {
          event.preventDefault()
          const data = new FormData(event.currentTarget)
          const minutes = Number(data.get('minutes'))
          const at = Date.now()
          setNow(at)
          setTimer({ id: crypto.randomUUID(), subject: String(data.get('subject')).trim(), minutes, ends: at + minutes * 60_000, remaining: 0 })
        }}>
          <label className="grid gap-1 text-sm">{t('Subject')}<input className="field" name="subject" list="focus-subjects" maxLength={80} /></label>
          <datalist id="focus-subjects">{subjects.map((subject) => <option key={subject} value={subject} />)}</datalist>
          <label className="grid gap-1 text-sm">{t('Minutes')}<input className="field w-25" name="minutes" type="number" min="1" max="180" defaultValue="25" required /></label>
          <Button variant="leaf" type="submit">{t('Start focus')}</Button>
        </form>
      )}
      <h3 className="text-sm font-medium">{t('Recent focus sessions')}</h3>
      {plan.sessions.length ? (
        <ul className="grid gap-2 text-sm text-soft">
          {[...plan.sessions].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 5).map((session) => (
            <li key={session.id}>{session.subject || t('General study')} · {t('{n} min', { n: session.minutes })}</li>
          ))}
        </ul>
      ) : <p className="text-sm text-muted">{t('Completed sessions appear here.')}</p>}
    </section>
  )
}
