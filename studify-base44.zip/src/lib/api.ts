/** Dispatch a JSON request to the local demo routes. Resolves `{ ok, data }` and never throws. */
export async function postJson<T = Record<string, unknown>>(
  url: string,
  payload: unknown,
): Promise<{ ok: true; data: T } | { ok: false; error: string; errors?: Record<string, string> }> {
  try {
    const { default: demoApi } = await import('./demoApi')
    const res = await demoApi.request(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) })
    const data = (await res.json().catch(() => ({}))) as T & { error?: string; errors?: Record<string, string> }
    if (!res.ok) return { ok: false, error: data.error ?? 'Something went wrong. Try again.', errors: data.errors }
    return { ok: true, data }
  } catch {
    return { ok: false, error: 'Something went wrong. Try again.' }
  }
}
