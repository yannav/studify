import { useStored } from './storage'

export type PlanKind = 'task' | 'topic' | 'exam' | 'note'
export type PlanItem = {
  id: string
  kind: PlanKind
  title: string
  subject: string
  date: string
  content: string
  done: boolean
  docId: string
}
export type FocusSession = { id: string; subject: string; minutes: number; at: string }
export type StudyPlan = { items: PlanItem[]; sessions: FocusSession[] }

export type RunningFocus = { id: string; subject: string; minutes: number; ends: number; remaining: number }
export const FOCUS_KEY = 'study-focus'
export const useFocusTimer = () => useStored<RunningFocus | null>(FOCUS_KEY, null)

export const PLAN_KEY = 'study-plan'
export const EMPTY_PLAN: StudyPlan = { items: [], sessions: [] }
export const useStudyPlan = () => useStored(PLAN_KEY, EMPTY_PLAN)

const record = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value)
const str = (value: unknown) => typeof value === 'string' ? value : ''
const kinds = ['task', 'topic', 'exam', 'note']

export function validStudyPlan(value: unknown): value is StudyPlan {
  return record(value) && Array.isArray(value.items) && Array.isArray(value.sessions)
    && value.items.every((item) => record(item) && kinds.includes(str(item.kind)) && typeof item.done === 'boolean'
      && ['id', 'title', 'subject', 'date', 'content', 'docId'].every((k) => typeof item[k] === 'string'))
    && value.sessions.every((session) => record(session) && typeof session.id === 'string'
      && typeof session.subject === 'string' && typeof session.at === 'string'
      && typeof session.minutes === 'number' && Number.isFinite(session.minutes) && session.minutes > 0)
}

export function examReadiness(coverage: number, quiz: number, minutes: number) {
  // Study Astra weights syllabus coverage and quiz performance at 40% each.
  return Math.round(coverage * 0.4 + quiz * 0.4 + Math.min(100, minutes / 6) * 0.2)
}

export function importAstraPlan(text: string): StudyPlan | null {
  const raw: unknown = JSON.parse(text)
  const data = record(raw) && record(raw.data) ? raw.data : raw
  if (!record(data) || !['subjects', 'tasks', 'notes', 'exams', 'sessions'].some((key) => Array.isArray(data[key]))) return null
  const list = (value: unknown) => Array.isArray(value) ? value.filter(record) : []
  const subjects = list(data.subjects)
  const subjectName = (id: unknown) => str(subjects.find((subject) => subject.id === id)?.name) || str(id)
  const items: PlanItem[] = []
  function add(kind: PlanKind, item: Record<string, unknown>, options: Partial<PlanItem>) {
    const title = str(item.title || item.name).trim()
    if (!title) return
    items.push({
      id: `astra-${kind}-${str(item.id) || items.length}`,
      kind, title, subject: subjectName(item.subject || item.subjectId), date: '', content: '', done: false, docId: '',
      ...options,
    })
  }
  for (const task of list(data.tasks)) add('task', task, {
    date: str(task.dueDate).slice(0, 10), content: str(task.description), done: task.completed === true,
  })
  for (const note of list(data.notes)) add('note', note, { content: str(note.content) })
  for (const exam of list(data.exams)) add('exam', exam, { date: str(exam.date).slice(0, 10) })
  for (const subject of subjects) {
    for (const chapter of list(subject.chapters)) {
      for (const topic of list(chapter.topics)) add('topic', topic, {
        subject: str(subject.name), content: str(chapter.name || chapter.title), done: topic.status === 'completed',
      })
    }
  }
  const sessions = list(data.sessions).flatMap((session, index) => {
    const minutes = Number(session.duration)
    return session.completed === true && Number.isFinite(minutes) && minutes > 0
      ? [{ id: `astra-focus-${str(session.id) || index}`, subject: subjectName(session.subject), minutes, at: str(session.date || session.createdAt) }]
      : []
  })
  return { items, sessions }
}

export function mergeStudyPlans(current: StudyPlan, incoming: StudyPlan): StudyPlan {
  const merge = <T extends { id: string }>(existing: T[], added: T[]) =>
    [...new Map([...added, ...existing].map((item) => [item.id, item])).values()]
  return { items: merge(current.items, incoming.items), sessions: merge(current.sessions, incoming.sessions) }
}
